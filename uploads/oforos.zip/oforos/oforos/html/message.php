<?
	// Generates the message view based on URL parameters
	
	// Main entry point
	function messageDotPHP(){ ?>
	<?	if(isset($_GET['message'])){
			$result = mysql_query(getMessage($_GET['message']));
		}else{
			$result = mysql_query(getMessage(""));
		}
		while ($row = mysql_fetch_assoc($result)) {
			getMessageGlobals($row);
			if(isset($_GET['message'])){
				$GLOBALS['adminObjectId'] = $GLOBALS['messageId'];
			}	?>
			<div class="clear">
				<div class="fl">
				<?	if(isset($_GET['message'])){ ?>
						<h1><? printHTML($GLOBALS['objectTitle']); ?></h1>
				<?	}else{ ?>
						<h2><a href="<? printHTML(fullURL(getLangVar("messageURL") . $GLOBALS['messageId'])); ?>"><? printHTML($GLOBALS['objectTitle']); ?></a></h2>
				<?	} ?>
				</div>
				<div class="fr">
				<?	$result2 = mysql_query(getUser($GLOBALS['createdId'], "userId"));
					
					$row2 = mysql_fetch_assoc($result2);
					getUserGlobals($row2);
				?>	<h3>Created By: <a href="<? printHTML(fullURL(getLangVar("userURL")) . $GLOBALS['userId']); ?>"><? printHTML($GLOBALS['userName']); ?></a></h3>
				</div>
				<div class="clear">
					<? printHTML($GLOBALS['objectText']); ?>
				</div>
				<div class="fl">
					<h4>Created: <? printHTML(date($GLOBALS['dateTimeFormat'], addDate($GLOBALS['createdOn'], $GLOBALS['timeOffset'], "hour"))); ?></h4>
				</div>
				<div class="fr">
					<h4><a href="<? printHTML(fullURL(getLangVar("eventURL") . $GLOBALS['objectId'], "create")); ?>">Sub Event</a> | <a href="<? printHTML(fullURL(getLangVar("messageURL") . $GLOBALS['objectId'], "create")); ?>">Reply</a> | <a href="<? printHTML(fullURL(getLangVar("fileURL") . $GLOBALS['objectId'], "create")); ?>">Attach File</a> | <a href="<? printHTML(fullURL(getLangVar("messageURL") . $GLOBALS['messageId'], "edit")); ?>">Edit</a></h4>
				</div>
			</div>
	<?	}
		
		// Gets related objects
		if(isset($_GET['message'])){
			getRelatedObjects($GLOBALS['objectId']);
		}
	}
?>