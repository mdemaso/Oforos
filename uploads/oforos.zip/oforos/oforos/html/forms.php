<?
	// Contains all of the creating, editing, and deleting of objects and users
	
	// Main entry point, decides which functions to call based on URL
	function formsDotPHP(){
		// Display dropdown if logged in, else print out register header
		if(check()){
			createaDropdown($_GET['create']); 
		}else{ ?>
			<div class="clear">
				<h1>Register</h1>
			</div>
	<?	}
		
		// Main login, got to the correct function based on URL
		// Most check for a logged in user, some check for admin rights
		if($_GET['create'] == "message" && check()) {
			messageForm("create");
		}else if($_GET['create'] == "event" && check()) {
			eventForm("create");
		}else if($_GET['create'] == "file" && check()) {
			fileForm("create");
		}else if($_GET['create'] == "attendance" && check()) {
			attendanceForm("create");
		}else if($_GET['create'] == "user") {
			userForm("create");
		}else if($_GET['create'] == "userData" && check()) {
			if(adminCheck()){
				userDataForm("create");
			}
		}else if($_GET['create'] == "group" && check()) {
			if(adminCheck()){
				groupForm("create");
			}
		}else if($_GET['commit'] == "message" && check()) {
			messageCommit();
		}else if($_GET['commit'] == "event" && check()) {
			eventCommit();
		}else if($_GET['commit'] == "file" && check()) {
			fileCommit();
		}else if($_GET['commit'] == "attendance" && check()) {
			attendanceCommit();
		}else if($_GET['commit'] == "user") {
			userCommit();
		}else if($_GET['commit'] == "environment" && check()) {
			environmentCommit();
		}else if($_GET['edit'] == "message" && check()) {
			messageEdit();
		}else if($_GET['edit'] == "event" && check()) {
			eventEdit();
		}else if($_GET['edit'] == "file" && check()) {
			fileEdit();
		}else if($_GET['edit'] == "user" && check()) {
			userEdit();
		}else if($_GET['edit'] == "environment" && check()) {
			if(adminCheck()){
				environmentForm();
			}
		}else if($_GET['delete'] == "message" && check()) {
			messageDelete();
		}else if($_GET['delete'] == "event" && check()) {
			eventDelete();
		}else if($_GET['delete'] == "file" && check()) {
			fileDelete();
		}else if($_GET['delete'] == "user" && check()) {
			if(adminCheck()){
				userDelete();
			}
		// Redirect if user isn't logged in and not registering
		}else if(!check()){
			header('Location:' . fullURL("login/"));
		}
	}
	
	// Creates the object drop down, includes user in an admin
	function createaDropdown($selected = ""){ ?>
		<div class="clear fl">
			<label for="createa">Create a </label>
			<select id="createa" name="createa" onchange="location.href = '<? printHTML(fullURL("", "create")); ?>' + document.getElementById('createa').value">
				<option value="">...</option>
				<option value="message" <? if($selected == "message"){ printHTML('selected="selected"'); } ?>>Message</option>
				<option value="event" <? if($selected == "event"){ printHTML('selected="selected"'); } ?>>Event</option>
				<option value="file" <? if($selected == "file"){ printHTML('selected="selected"'); } ?>>File</option>
				<? if(adminCheck()){ ?>
				<option value="user" <? if($selected == "user"){ printHTML('selected="selected"'); } ?>>User</option>
				<? } ?>
			</select>
		</div>
<?	}
	
	// Creates the form for the base class object
	// Contains javascript for the YUI editor
	function objectForm(){ ?>
		<div class="fr">
			<label for="parentId">Parent: </label>
				<select id="parentId" name="parentId">
					<option value="">Select One</option>
				<?	$result = mysql_query(getObject("", ""));
				
					while ($row = mysql_fetch_assoc($result)) {
						@extract($row);?>
					<option value="<? printHTML($objectId); ?>" <? if($GLOBALS['parentId'] == $objectId){ printHTML('selected="selected"'); } ?>><? printHTML($objectTitle); ?></option> <?	
					} ?>
				</select>
			<label for="objectTitle">Title: </label><input id="objectTitle" name="objectTitle" type="text" size="100" value="<? printHTML($GLOBALS['objectTitle']); ?>"></input>
		</div>
		<div class="clear">
			<textarea id="objectText" name="objectText"><? printHTML($GLOBALS['objectText']); ?></textarea>
			<script>
				(function() {
					var Dom = YAHOO.util.Dom,
						Event = YAHOO.util.Event;
					
					var myConfig = {
						titlebar: 'Body', 
						height: '300px',
						handleSubmit: true,
						width: '100%',
						animate: true,
						autoHeight: true
					};
					
					var myEditor = new YAHOO.widget.Editor('objectText', myConfig);
					myEditor.render();
				 
				})();
			</script>
		</div>
		<input id="createdId" name="createdId" type="hidden" value="<? if(isset($GLOBALS['createdId'])){printHTML($GLOBALS['createdId']);}else{printHTML(getLangVar("userId"));} ?>"></input>
		<input id="objectId" name="objectId" type="hidden" value="<? printHTML($GLOBALS['objectId']); ?>"></input>
<?	}
	
	// Generates the forms for a message
	function messageForm($sqlType){ ?>
		<form name="eventInput" action="<? printHTML(fullURL(getLangVar("messageURL"), "commit")); ?>" method="post">
	<?	objectForm();?>
		<div class="fr">
			<input type="submit" value="Submit"></input>
		</div>
		<input id="sqlType" name="sqlType" type="hidden" value="<? printHTML($sqlType); ?>"></input>
		<input id="messageId" name="messageId" type="hidden" value="<? printHTML($GLOBALS['messageId']); ?>"></input>
		</form>
<?	}
	
	// Captures variables and creates a prefilled form for messages
	function messageEdit(){
		$result = mysql_query(getMessage($_GET['message']));
		$GLOBALS['adminObjectId'] = $_GET['message'];
		if($row = mysql_fetch_assoc($result)) {
			getMessageGlobals($row);
			messageForm("edit");
		}
	}
	
	// Runs SQL to delete messages, redirects to the main list
	function messageDelete(){
		$result = mysql_query(getMessage($_GET['message']));
		if($row = mysql_fetch_assoc($result)) {
			getMessageGlobals($row);
			mysql_query(deleteObject($GLOBALS['objectId']));
			mysql_query(deleteMessage($GLOBALS['messageId']));
		}
		header('Location:' . fullURL(getLangVar("threadsURL")));
	}
	
	// Runs the SQL to create or edit a message entry, also captures the forwarding id
	// and sends you to the new entry upon completion
	function messageCommit(){
		if($_POST['sqlType'] == "create") {
			$result = mysql_query(createObject(getLangVar("userId"), $_POST['objectText'], $_POST['parentId'], $_POST['objectTitle']));
			$result = mysql_query(createMessage(mysql_insert_id(), $_POST['privateId']));
			$forwardId = mysql_insert_id();
		} else if($_POST['sqlType'] == "edit") {
			$result = mysql_query(editObject($_POST['objectText'], $_POST['parentId'], $_POST['objectTitle'], $_POST['objectId']));
			$result = mysql_query(editMessage($GLOBALS['objectId'], $_POST['privateId'], $_POST['messageId']));
			$forwardId = $_POST['messageId'];
		}
		header('Location:' . fullURL(getLangVar("messageURL") . $forwardId));
	}
	
	// Generates the event creation form
	// Contains javascript for the YUI calendar
	function eventForm($sqlType){ ?>
		<form name="eventInput" action="<? printHTML(fullURL(getLangVar("eventURL"), "commit")); ?>" method="post">
	<?	objectForm();?>
		<script type="text/javascript">
			function padDigits(n, totalDigits){ 
				n = n.toString(); 
				var pd = ''; 
				if (totalDigits > n.length){ 
					for (i=0; i < (totalDigits-n.length); i++){ 
						pd += '0'; 
					}
				} 
				return pd + n.toString(); 
			}
			YAHOO.util.Event.onDOMReady(function(){
		 
				var Event = YAHOO.util.Event,
					Dom = YAHOO.util.Dom,
					dialog,
					calendar;
		 
				var showBtn = Dom.get("show");
		 
				Event.on(showBtn, "click", function() {
		 
					// Lazy Dialog Creation - Wait to create the Dialog, and setup document click listeners, until the first time the button is clicked.
					if (!dialog) {
		 
						// Hide Calendar if we click anywhere in the document other than the calendar
						Event.on(document, "click", function(e) {
							var el = Event.getTarget(e);
							var dialogEl = dialog.element;
							if (el != dialogEl && !Dom.isAncestor(dialogEl, el) && el != showBtn && !Dom.isAncestor(showBtn, el)) {
								dialog.hide();
							}
						});
		 
						function resetHandler() {
							// Reset the current calendar page to the select date, or 
							// to today if nothing is selected.
							var selDates = calendar.getSelectedDates();
							var resetDate;
				
							if (selDates.length > 0) {
								resetDate = selDates[0];
							} else {
								resetDate = calendar.today;
							}
				
							calendar.cfg.setProperty("pagedate", resetDate);
							calendar.render();
						}
				
						function closeHandler() {
							dialog.hide();
						}
		 
						dialog = new YAHOO.widget.Dialog("container", {
							visible:false,
							context:["show", "tl", "bl"],
							buttons:[ {text:"Reset", handler: resetHandler, isDefault:true}, {text:"Close", handler: closeHandler}],
							draggable:false,
							close:true
						});
						dialog.setHeader('Pick A Date');
						dialog.setBody('<div id="cal"></div>');
						dialog.render(document.body);
		 
						dialog.showEvent.subscribe(function() {
							if (YAHOO.env.ua.ie) {
								// Since we're hiding the table using yui-overlay-hidden, we 
								// want to let the dialog know that the content size has changed, when
								// shown
								dialog.fireEvent("changeContent");
							}
						});
					}
		 
					// Lazy Calendar Creation - Wait to create the Calendar until the first time the button is clicked.
					if (!calendar) {
		 
						calendar = new YAHOO.widget.Calendar("cal", {
							iframe:false,          // Turn iframe off, since container has iframe support.
							hide_blank_weeks:true  // Enable, to demonstrate how we handle changing height, using changeContent
						});
						calendar.render();
		 
						calendar.selectEvent.subscribe(function() {
							if (calendar.getSelectedDates().length > 0) {
		 
								var selDate = calendar.getSelectedDates()[0];
				
								Dom.get("date").value = (selDate.getMonth() + 1) + "/" + selDate.getDate() + "/" + selDate.getFullYear();
								Dom.get("hiddenDateTime").value = selDate.getFullYear() + "-" + padDigits((selDate.getMonth() + 1), 2) + "-" + padDigits(selDate.getDate(), 2);
							} else {
								Dom.get("date").value = "";
							}
							dialog.hide();
						});
		 
						calendar.renderEvent.subscribe(function() {
							// Tell Dialog it's contents have changed, which allows 
							// container to redraw the underlay (for IE6/Safari2)
							dialog.fireEvent("changeContent");
						});
					}
		 
					var seldate = calendar.getSelectedDates();
		 
					if (seldate.length > 0) {
						// Set the pagedate to show the selected date if it exists
						calendar.cfg.setProperty("pagedate", seldate[0]);
						calendar.render();
					}
		 
					dialog.show();
				});
			});
		</script>
		<div>
			<label for="date">Date: </label><input type="text" id="date" name="date" value="<? if(isset($_GET['month'])){printHTML($_GET['month'] . "/" . $_GET['day'] . "/" . $_GET['year']);}else{printHTML($GLOBALS['returnMonth'] . "/" . $GLOBALS['returnDay'] . "/" . $GLOBALS['returnYear']);} ?>"></input><button type="button" id="show" title="Show Calendar"><img src="<? printHTML(fullURL(getLangVar("imageURL"))); ?>calbtn.gif" width="18" height="18" alt="Calendar" ></button>
			<?
				if($GLOBALS['returnTime']){
					$time = explode(" ", $GLOBALS['returnTime']);
					$hourMin = explode(":", $time[0]);
				}
			?>
			<label for="time">Time: </label><input id="hour" name="hour" type="text" maxlength="2" size="2" value="<? printHTML($hourMin[0]); ?>"></input>:<input id="minute" name="minute" type="text" maxlength="2" size="2" value="<? printHTML($hourMin[1]); ?>"></input> 
			<select id="ampm" name="ampm">
				<option value="0"<? if($time[1] == "AM"){printHTML(' selected="selected"');} ?>>AM</option>
				<option value="12"<? if($time[1] == "PM"){printHTML(' selected="selected"');} ?>>PM</option>
			</select>
			<input id="hiddenDateTime" name="hiddenDateTime" type="hidden" value="<? if(isset($_GET['month'])){printHTML($_GET['year'] . "-" . sprintf("%02d", $_GET['month']) . "-" . sprintf("%02d", $_GET['day']));}else{printHTML($GLOBALS['returnYear'] . "-" . sprintf("%02d", $GLOBALS['returnMonth']) . "-" . sprintf("%02d", $GLOBALS['returnDay']));} ?>"></input>
			<label for="duration">Duration (in minutes): </label><input id="duration" name="duration" type="text" value="<? printHTML($GLOBALS['duration']); ?>"></input>
			<label for="location">Location: </label><input id="location" name="location" type="text" value="<? printHTML($GLOBALS['location']); ?>"></input>
		</div>
		<div class="fr">
			<input type="submit" value="Submit"></input>
		</div>
			<input id="sqlType" name="sqlType" type="hidden" value="<? printHTML($sqlType); ?>"></input>
			<input id="calendarId" name="calendarId" type="hidden" value="<? printHTML($GLOBALS['calendarId']); ?>"></input>
		</form>
<?	}
	
	// Captures variables and creates a prefilled form for messages
	function eventEdit(){
		$result = mysql_query(getEvent($_GET['event']));
		$GLOBALS['adminObjectId'] = $_GET['event'];
		if($row = mysql_fetch_assoc($result)) {
			getEventGlobals($row);
			eventForm("edit");
		}
	}
	
	// Commits event data to the database, gets forwarding variable and send you to completed event
	function eventCommit(){
		// Get the full 24 hour
		$fullHour = $_POST['hour'] + $_POST['ampm'];
		if($_POST['sqlType'] == "create") {
			$result = mysql_query(createObject(getLangVar("userId"), $_POST['objectText'], $_POST['parentId'], $_POST['objectTitle']));
			$result = mysql_query(createCalendar($_POST['attendingGroup'], $_POST['duration'], $_POST['location'], mysql_insert_id(), $_POST['hiddenDateTime'] . " " . sprintf("%02d",$fullHour) . ":" . $_POST['minute'] . ":00", $_POST['calendarId']));
			$forwardId = mysql_insert_id();
		} else if($_POST['sqlType'] == "edit") {
			$result = mysql_query(editObject($_POST['objectText'], $_POST['parentId'], $_POST['objectTitle'], $_POST['objectId']));
			$result = mysql_query(editCalendar($_POST['attendingGroup'], $_POST['duration'], $_POST['location'], $_POST['objectId'], $_POST['hiddenDateTime'] . " " . $fullHour . ":" . $_POST['minute'] . ":00", $_POST['calendarId']));
			$forwardId = $_POST['calendarId'];
		}
		header('Location:' . fullURL(getLangVar("eventURL") . $forwardId));
	}
	
	// Deletes the event from the database and forwards to the calendar
	function eventDelete(){
		$result = mysql_query(getEvent($_GET['event']));
		if($row = mysql_fetch_assoc($result)) {
			getEventGlobals($row);
			mysql_query(deleteObject($GLOBALS['objectId']));
			mysql_query(deleteCalendar($GLOBALS['eventId']));
		}
		header('Location:' . fullURL(getLangVar("calendarURL")));
	}
	
	// Generates the form for creating or editing files
	function fileForm($sqlType){ ?>
		<form name="eventInput" action="<? printHTML(fullURL(getLangVar("fileURL"), "commit")); ?>" method="post" enctype="multipart/form-data">
	<?	objectForm(); ?>
			<div>
				<label for="file">Filename:</label><input type="file" name="file" id="file" />
			</div>
			<div class="fr">
				<input type="submit" value="Submit"></input>
			</div>
			<input id="sqlType" name="sqlType" type="hidden" value="<? printHTML($sqlType); ?>"></input>
			<input id="fileId" name="fileId" type="hidden" value="<? printHTML($GLOBALS['fileId']); ?>"></input>
		</form>
<?	}
	
	// Captures variables and creates a prefilled form for files
	function fileEdit(){
		$result = mysql_query(getFile($_GET['file']));
		$GLOBALS['adminObjectId'] = $_GET['file'];
		if($row = mysql_fetch_assoc($result)) {
			getFileGlobals($row);
			fileForm("edit");
		}
	}
	
	// Commits the file entry to the database and sends the file to the server and forwards you to the file
	function fileCommit(){
		// Target folder, make sure it is 777
		$target = "uploads/";
		
		// Appends the file name
		$target = $target . basename( $_FILES['file']['name']);
		
		// Moves the file to target
		move_uploaded_file($_FILES['file']['tmp_name'], $target);
		if($_POST['sqlType'] == "create") {
			$result = mysql_query(createObject(getLangVar("userId"), $_POST['objectText'], $_POST['parentId'], $_POST['objectTitle']));
			$result = mysql_query(createFile(fullURL($_FILES["file"]["name"], "uploads"), $_FILES["file"]["size"], $_FILES["file"]["type"], mysql_insert_id()));
			$forwardId = mysql_insert_id();
		} else if($_POST['sqlType'] == "edit") {
			$result = mysql_query(editObject($_POST['objectText'], $_POST['parentId'], $_POST['objectTitle'], $_POST['objectId']));
			$result = mysql_query(editFile());
			$forwardId = $_POST['fileId'];
		}
		header('Location:' . fullURL(getLangVar("fileURL") . $forwardId));
	}
	
	// Removes the file from the database, not the server for linking
	function fileDelete(){
		$result = mysql_query(getFile($_GET['file']));
		if($row = mysql_fetch_assoc($result)) {
			getFileGlobals($row);
			mysql_query(deleteObject($GLOBALS['objectId']));
			mysql_query(deleteFile($GLOBALS['fileId']));
			die();
		}
		header('Location:' . fullURL(getLangVar("filesURL")));
	}
	
	// Generates the form for creating or edting users
	function userForm($sqlType){ ?>
		<form name="eventInput" action="<? printHTML(fullURL(getLangVar("userURL"), "commit")); ?>" method="post">
			<div class="clear">
				<div class="userEditName fl">
					<label for="userEmail fl">Email: </label>
				</div>
				<div class="userEditField fr">
					<input id="userEmail" name="userEmail" type="text" value="<? printHTML($GLOBALS['userEmail']); ?>"></input>
				</div>
				<div class="userEditName fl">
					<label for="userPassword">Password: </label>
				</div>
				<div class="userEditField fr">
					<input id="userPassword" name="userPassword" type="password"></input>
				</div>
				<div class="userEditName fl">
					<label for="userName">Name: </label>
				</div>
				<div class="userEditField fr">
					<input id="userName" name="userName" type="text" value="<? printHTML($GLOBALS['userName']); ?>"></input>
				</div>
				<div class="userEditName fl">
					<label for="icon">Icon (URL): </label>
				</div>
				<div class="userEditField fr">
					<input id="icon" name="icon" type="text" value="<? printHTML($GLOBALS['icon']); ?>"></input>
				</div>
			<?	// Get user data if any
				$getDataResult = mysql_query(getData());
				$userDataCount = 0;
				while($getDataRow = mysql_fetch_assoc($getDataResult)) {
					getDataGlobals($getDataRow);
					$data = array($GLOBALS['userId'], $GLOBALS['dataId']);
					$getUserDataResult = mysql_query(getUserData($data, "both"));
					if(@$getUserDataRow = mysql_fetch_assoc($getUserDataResult)) {
						getUserDataGlobals($getUserDataRow);
					}
					if($GLOBALS['data'] == ""){
						$userDataQueryType = "create";
					} else {
						$userDataQueryType = "edit";
					}?>
				<div class="userEditName fl">
					<label for="<? printHTML("userData" . $userDataCount); ?>"><? printHTML($GLOBALS['dataName']); ?>: </label>
				</div>
				<div class="userEditField fr">
					<input id="<? printHTML("userData" . $userDataCount); ?>" name="<? printHTML("userData" . $userDataCount); ?>" type="text" value="<? printHTML($GLOBALS['data']); ?>"></input>
					<input id="<? printHTML("userDataId" . $userDataCount); ?>" name="<? printHTML("userDataId" . $userDataCount); ?>" type="hidden" value="<? printHTML($GLOBALS['dataId']); ?>"></input>
					<input id="<? printHTML("userDataQueryType" . $userDataCount); ?>" name="<? printHTML("userDataQueryType" . $userDataCount); ?>" type="hidden" value="<? printHTML($userDataQueryType); ?>"></input>
				</div>
			<?	$GLOBALS['data'] = "";
				$userDataCount++;
				}
				?>
				<div class="clear fr">
					<input type="submit" value="Submit"></input>
				</div>
				<input id="sqlType" name="sqlType" type="hidden" value="<? printHTML($sqlType); ?>"></input>
				<input id="userDataCount" name="userDataCount" type="hidden" value="<? printHTML($userDataCount); ?>"></input>
				<input id="userId" name="userId" type="hidden" value="<? printHTML($GLOBALS['userId']); ?>"></input>
				<input id="userPasswordHidden" name="userPasswordHidden" type="hidden" value="<? printHTML($GLOBALS['userPassword']); ?>"></input>
			</div>
		</form>
<?	}
	
	// Captures variables and creates a prefilled form for users
	function userEdit(){
		$result = mysql_query(getUser($_GET['user']));
		$GLOBALS['adminObjectId'] = $_GET['user'];
		if($row = mysql_fetch_assoc($result)) {
			getUserGlobals($row);
			userForm("edit");
		}
	}
	
	// Changes the value of the deleted column to `1`, keeps user for legacy links
	function userDelete(){
		$result = mysql_query(getUser($_GET['user']));
		if($row = mysql_fetch_assoc($result)) {
			getUserGlobals($row);
			mysql_query(deleteUser($GLOBALS['userId']));
		}
		header('Location:' . fullURL(""));
	}
	
	// Commits changes to the database
	function userCommit(){
		if($_POST['sqlType'] == "create") {
			$result = mysql_query(createUser($_POST['icon'], $_POST['userEmail'], $_POST['userName'], md5($_POST['userPassword'])));
			$userId = mysql_insert_id();
			// Commits user data to the database
			for($i = 0; $i < $_POST['userDataCount']; $i++){
				if($_POST['userDataQueryType' . $i] == "create"){
					$result = mysql_query(createUserData($_POST['userData' . $i], $_POST['userDataId' . $i], $userId));
				} else {
					$result = mysql_query(editUserData($_POST['userData' . $i], $_POST['userDataId' . $i], $userId));
				}
			}
			$forwardId = $userId;
		} else if($_POST['sqlType'] == "edit") {
			// Decides whether or not a change to the password was made
			if($_POST['userPassword'] == ""){
				$password = $_POST['userPasswordHidden'];
			}else{
				$password = md5($_POST['userPassword']);
			}
			$result = mysql_query(editUser($_POST['icon'], $_POST['userEmail'], $_POST['userName'], $password, $_POST['userId']));
			// Commits user data to the database
			for($i = 0; $i < $_POST['userDataCount']; $i++){
				// Decides on UPDATE or INSERT for user data based on whether it exsited
				if($_POST['userDataQueryType' . $i] == "create"){
					$result = mysql_query(createUserData($_POST['userData' . $i], $_POST['userDataId' . $i], $_POST['userId']));
				} else {
					$result = mysql_query(editUserData($_POST['userData' . $i], $_POST['userDataId' . $i], $_POST['userId']));
				}
			}
			$forwardId = $_POST['userId'];
		}
		header('Location:' . fullURL(getLangVar("userURL") . $forwardId));
	}
	
	// Commit changes to attendance
	function attendanceCommit(){
			for($i = 0; $i < $_POST['numberOfUsers']; $i++){
				$result = mysql_query($_POST['attended' . $i]);
			}
			$forwardId = $_POST['calendarId'];
		header('Location:' . fullURL(getLangVar("eventURL") . $forwardId));
	}
	
	// Generate form for environment variables
	function environmentForm(){?>
		<div class="clear">
			<div class="tc">
				<h1>Evironment Variables</h1>
			</div>
			<form name="evironmentEdit" action="<? printHTML(fullURL("environment/", "commit")); ?>" method="post">
				<div class="userEditName fl clear">
					<label>Site Name:</label>
				</div>
				<div class="userEditField fr">
					<input name="siteName" id="siteName" type="text" value="<? printHTML($GLOBALS['siteName']); ?>"></input>
				</div>
				<div class="userEditName fl clear" style="height: 200px; padding-bottom: 10px;">
					<label>Site Description:</label>
				</div>
				<div class="userEditField fr" style="height: 200px; padding-bottom: 10px;">
					<textarea name="siteDescription" id="siteDescription" style="width: 100%; height: 200px;"><? printHTML($GLOBALS['siteDescription']); ?></textarea>
				</div>
				<div class="userEditName fl clear">
					<label for="adminGroup">Admin Group: </label>
				</div>
				<div class="userEditField fr">
					<select id="adminGroup" name="adminGroup">
						<option value="">Select One</option>
					<?	$result = mysql_query(getGroup(""));
						
						while ($row = mysql_fetch_assoc($result)) {
							getGroupGlobals($row); ?>
						<option value="<? printHTML($GLOBALS['groupId']); ?>"<? if($GLOBALS['groupId'] == $GLOBALS['adminGroup']){printHTML(' selected="selected"');} ?>><? printHTML($GLOBALS['groupName']); ?></option> <?	
						}	?>
					</select>
				</div>
				<div class="userEditName fl clear">
					<label>Time Offset:</label>
				</div>
				<div class="userEditField fr">
					<input name="timeOffset" id="timeOffset" type="text" value="<? printHTML($GLOBALS['timeOffset']); ?>"></input>
				</div>
				<div class="userEditName fl clear">
					<label>Date Time Format:</label>
				</div>
				<div class="userEditField fr">
					<input name="dateTimeFormat" id="dateTimeFormat" type="text" value="<? printHTML($GLOBALS['dateTimeFormat']); ?>"></input>
				</div>
				<div class="userEditName fl clear" style="height: 400px; padding-bottom: 10px;">
					<label>CSS:</label>
				</div>
				<div class="userEditField fr" style="height: 400px; padding-bottom: 10px;">
					<textarea name="css" id="css" style="width: 100%; height: 400px;"><? printHTML($GLOBALS['css']); ?></textarea>
				</div>
				<div class="clear fr">
					<input id="sqlType" name="sqlType" type="hidden" value="edit"></input>
					<input type="submit" value="Submit"></input>
				</div>
			</form>
		</div>
<?	}
	
	// Commit enivronment variables to the database and redirect back to editing them
	function environmentCommit(){
		if($_POST['sqlType'] == "edit") {
			$result = mysql_query(editEnvironment($_POST['siteName'], $_POST['siteDescription'], $_POST['adminGroup'], $_POST['css'], $_POST['timeOffset'], $_POST['dateTimeFormat'], 1));
		}
		header('Location:' . fullURL("environment", "edit"));
	}
?>