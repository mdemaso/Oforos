<?
	// Displays the file list or the individual file
	
	// Main entry point
	function fileDotPHP(){
		// Gets the file or files based on URL
		if(isset($_GET['file'])){
			$result = mysql_query(getFile($_GET['file']));
		}else{
			$result = mysql_query(getFile(""));
		}
		
		// Displays what was retrieved
		while ($row = mysql_fetch_assoc($result)) {
			getFileGlobals($row);
			if(isset($_GET['file'])){
				$GLOBALS['adminObjectId'] = $GLOBALS['fileId'];
			}	?>
			<div class="clear">
				<div class="fl">
				<?	if(isset($_GET['file'])){ ?>
						<h1><? printHTML($GLOBALS['objectTitle']); ?></h1>
				<?	}else{ ?>
						<h2><a href="<? printHTML(fullURL(getLangVar("fileURL") . $GLOBALS['fileId'])); ?>"><? printHTML($GLOBALS['objectTitle']); ?></a></h2>
				<?	} ?>
				</div>
				<div class="fr">
				<?	$result2 = mysql_query(getUser($GLOBALS['createdId'], "userId"));
					
					$row2 = mysql_fetch_assoc($result2);
					getUserGlobals($row2);
				?>	<h3>Created By: <a href="<? printHTML(fullURL(getLangVar("userURL")) . $GLOBALS['userId']); ?>"><? printHTML($GLOBALS['userName']); ?></a></h3>
				</div>
				<div class="cl">
					<? printHTML($GLOBALS['objectText']); ?>
				</div>
			<?	if(isset($_GET['file'])){ ?>
				<div>
					<h3><a href="<? printHTML($GLOBALS['filePath']); ?>">Download</a></h3>
				</div>
			<?	}	?>
				<div class="fl">
					<h4>Created: <? printHTML(date($GLOBALS['dateTimeFormat'], addDate($GLOBALS['createdOn'], $GLOBALS['timeOffset'], "hour"))); ?></h4>
				</div>
				<div class="fr">
					<h4><a href="<? printHTML(fullURL(getLangVar("eventURL") . $GLOBALS['objectId'], "create")); ?>">Sub Event</a> | <a href="<? printHTML(fullURL(getLangVar("messageURL") . $GLOBALS['objectId'], "create")); ?>">Reply</a> | <a href="<? printHTML(fullURL(getLangVar("fileURL") . $GLOBALS['objectId'], "create")); ?>">Attach File</a> | <a href="<? printHTML(fullURL(getLangVar("fileURL") . $GLOBALS['fileId'], "edit")); ?>">Edit</a></h4>
				</div>
			</div>
	<?	}
		
		// Gets related objects
		if(isset($_GET['file'])){
			getRelatedObjects($GLOBALS['objectId']);
		}
	}
	