<?
	// Displays all users or a user based on the URL
	
	// Main entry point
	function userDotPHP(){
		if(isset($_GET['user'])){
			$result = mysql_query(getUser($_GET['user']));
		}else{
			$result = mysql_query(getUser(""));
		}
		while ($row = mysql_fetch_assoc($result)) {
			getUserGlobals($row);
			if(isset($_GET['user'])){
				$GLOBALS['adminObjectId'] = $GLOBALS['userId'];
			}	?>
			<div style="clear">
				<div>
			<?	if(isset($_GET['user'])){ ?>
					<h1><? printHTML($GLOBALS['userName']); ?></h1>
			<?	}else{ ?>
					<h2><a href="<? printHTML(fullURL(getLangVar("userURL") . $GLOBALS['userId'])); ?>"><? printHTML($GLOBALS['userName']); ?></a></h2>
			<?	}	?>
				</div>
				<div>
					<img width="50px" src="<? printHTML($GLOBALS['icon']); ?>">
				</div>
				<div>
					Email: <? printHTML($GLOBALS['userEmail']); ?>
				</div>
			<?	$result2 = mysql_query(getUserData($GLOBALS['userId'], "userId"));
				while($row2 = mysql_fetch_assoc($result2)) {
					getUserDataGlobals($row2);
					$userDataCount = $userDataCount . $GLOBALS['dataId'] . ",";	?>
				<div>
					<? printHTML($GLOBALS['dataName']); ?>: <? printHTML($GLOBALS['data']); ?>
				</div>
			<?	}	?>
			</div>
	<?	}
	}
?>