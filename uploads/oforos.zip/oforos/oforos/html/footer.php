<?php
	// Creates the footer for each page
	
	// Main entry point
	function footerDotPHP() { ?>
		<div>
			<?php footerNavigation() ?>
		</div>
<?php
	}
?>