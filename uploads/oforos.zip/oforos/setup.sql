-- phpMyAdmin SQL Dump
-- version 2.11.9.4
-- http://www.phpmyadmin.net
--
-- Host: 10.6.186.5
-- Generation Time: Aug 09, 2010 at 09:18 PM
-- Server version: 5.0.91
-- PHP Version: 5.2.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `oforos`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--
-- Creation: Aug 08, 2010 at 08:44 PM
-- Last update: Aug 08, 2010 at 09:38 PM
--

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE IF NOT EXISTS `attendance` (
  `attendanceId` int(16) NOT NULL auto_increment,
  `attended` tinyint(1) NOT NULL,
  `calendarId` int(16) NOT NULL,
  `excused` tinyint(1) NOT NULL,
  `userId` int(16) NOT NULL,
  PRIMARY KEY  (`attendanceId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

-- --------------------------------------------------------

--
-- Table structure for table `calendar`
--
-- Creation: Aug 08, 2010 at 08:44 PM
-- Last update: Aug 09, 2010 at 11:15 AM
--

DROP TABLE IF EXISTS `calendar`;
CREATE TABLE IF NOT EXISTS `calendar` (
  `attendingGroup` int(16) NOT NULL,
  `calendarId` int(16) NOT NULL auto_increment,
  `duration` int(11) NOT NULL COMMENT 'In Minutes',
  `location` varchar(64) NOT NULL,
  `objectId` int(16) NOT NULL,
  `startDateTime` datetime NOT NULL,
  PRIMARY KEY  (`calendarId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=21 ;

-- --------------------------------------------------------

--
-- Table structure for table `data`
--
-- Creation: Aug 08, 2010 at 08:44 PM
-- Last update: Aug 08, 2010 at 08:44 PM
--

DROP TABLE IF EXISTS `data`;
CREATE TABLE IF NOT EXISTS `data` (
  `dataId` int(16) NOT NULL auto_increment,
  `dataName` varchar(64) NOT NULL,
  `dataType` text NOT NULL,
  `private` tinyint(1) NOT NULL,
  PRIMARY KEY  (`dataId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Table structure for table `environment`
--
-- Creation: Aug 08, 2010 at 08:44 PM
-- Last update: Aug 09, 2010 at 09:07 AM
--

DROP TABLE IF EXISTS `environment`;
CREATE TABLE IF NOT EXISTS `environment` (
  `environmentId` int(16) NOT NULL,
  `siteName` text NOT NULL,
  `siteDescription` longtext NOT NULL,
  `adminGroup` int(16) NOT NULL,
  `css` longtext NOT NULL,
  `timeOffset` int(2) NOT NULL,
  `dateTimeFormat` text NOT NULL,
  PRIMARY KEY  (`environmentId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `environment`
--

INSERT DELAYED IGNORE INTO `environment` (`environmentId`, `siteName`, `siteDescription`, `adminGroup`, `css`, `timeOffset`, `dateTimeFormat`) VALUES
(1, 'Oforos. Organization for organizations.', 'A website template dedicated to organization for small to medium organizations.', 1, '/* Clear calendar''s float, using dialog inbuilt form element */\r\n#container .bd form {\r\n clear:left;\r\n}\r\n\r\n/* Have calendar squeeze upto bd bounding box */\r\n#container .bd {\r\n padding:0;\r\n}\r\n\r\n#container .hd {\r\n text-align:left;\r\n}\r\n\r\n/* Center buttons in the footer */\r\n#container .ft .button-group {\r\n text-align:center;\r\n}\r\n\r\n/* Prevent border-collapse:collapse from bleeding through in IE6, IE7 */\r\n#container_c.yui-overlay-hidden table {\r\n *display:none;\r\n}\r\n\r\n/* Remove calendar''s border and set padding in ems instead of px, so we can specify an width in ems for the container */\r\n#cal {\r\n border:none;\r\n padding:1em;\r\n}\r\n\r\n/* Datefield look/feel */\r\n.datefield {\r\n position:relative;\r\n top:10px;\r\n left:10px;\r\n white-space:nowrap;\r\n border:1px solid black;\r\n background-color:#eee;\r\n width:25em;\r\n padding:5px;\r\n}\r\n\r\n.datefield input,\r\n.datefield button,\r\n.datefield label  {\r\n vertical-align:middle;\r\n}\r\n\r\n.datefield label  {\r\n font-weight:bold;\r\n}\r\n\r\n.datefield input  {\r\n width:15em;\r\n}\r\n\r\n.datefield button  {\r\n padding:0 5px 0 5px;\r\n margin-left:2px;\r\n}\r\n\r\n.datefield button img {\r\n padding:0;\r\n margin:0;\r\n vertical-align:middle;\r\n}\r\n\r\n/* Example box */\r\n.box {\r\n position:relative;\r\n height:30em;\r\n}\r\n\r\ndiv {\r\n text-align: left;\r\n display: block;\r\n}\r\n\r\na, a:visited {\r\n color: #555555;\r\n text-decoration: none;\r\n}\r\n\r\na:hover {\r\n color: #111111;\r\n text-decoration: none;\r\n}\r\n\r\n.clear {\r\n clear: both;\r\n}\r\n\r\n.span{\r\n width: 100%;\r\n}\r\n\r\n.fl{\r\n float: left;\r\n}\r\n\r\n.fr{\r\n float: right;\r\n}\r\n\r\n.cl {\r\n clear: left;\r\n}\r\n\r\n.cr {\r\n clear: right;\r\n}\r\n\r\n.oneseventh{\r\n height: 120px;\r\n}\r\n\r\n.dayNames, .oneseventh{\r\n width: 14%;\r\n}\r\n\r\n.dayNames{\r\n text-align: center;\r\n}\r\n\r\n.first{\r\n width: 1%;\r\n}\r\n\r\n.topLine {\r\n border-top: 1px solid #DDDDDD;\r\n}\r\n\r\n.bottomLine{\r\n border-bottom: 1px solid #DDDDDD;\r\n}\r\n\r\n.rightLine {\r\n border-right: solid 1px #DDDDDD;\r\n}\r\n\r\n.leftLine {\r\n border-left: solid 1px #DDDDDD;\r\n}\r\n\r\n.subObject{\r\n padding-left: 100px;\r\n padding-right: 50px;\r\n}\r\n\r\n.topBuffer{\r\n padding-top: 15px;\r\n}\r\n\r\n.bottomBuffer{\r\n padding-bottom: 20px;\r\n}\r\n\r\n.ar{\r\n text-align: right;\r\n}\r\n\r\n.cellEvent{\r\n padding: 5px;\r\n min-width: 70px;\r\n}\r\n\r\n.cellStyle{\r\n background-color: #BBAA88;\r\n height: 16px;\r\n overflow: hidden;\r\n margin-bottom: 2px;\r\n padding-left: 2px;\r\n}\r\n\r\n.cellStyle a{\r\n background-color: #BBAA88;\r\n height: 16px;\r\n overflow: hidden;\r\n margin-bottom: 2px;\r\n padding-left: 2px;\r\ndisplay: block;\r\n}\r\n\r\n.cellStyle:hover{\r\n background-color: #AA9977;\r\n}\r\n\r\n.cellStyle a:hover{\r\n background-color: #AA9977;\r\ndisplay: block;\r\n}\r\n\r\n.tc{\r\n text-align: center;\r\n}\r\n\r\n.userPanel{\r\n height: 120px;\r\n width: 400px;\r\n}\r\n\r\n.recentMessages{\r\n width: 300px\r\n}\r\n\r\n.loginPanel{\r\n height: 20px;\r\n}\r\n\r\n.userLinks{\r\n width: 100px;\r\n}\r\n\r\n.quickWeek{\r\n width: 100%;\r\n}\r\n\r\n.calfix{\r\n padding-right: 5px;\r\n}\r\n\r\n.userEditName{\r\n width: 30%;\r\n text-align: right;\r\n height: 30px;\r\n}\r\n\r\n.userEditField{\r\n width: 70%;\r\n text-align: left;\r\n height: 30px;\r\n}\r\n\r\n.logoArea{\r\n background-image: url(''http://oforos.tvolved.com/img/banner.png'');\r\n /* <? printHTML(fullURL(getLangVar("imageURL") . ''banner.png'')); ?> */\r\n background-repeat: no-repeat; height: 100px;\r\n}\r\n\r\n.siteMargins{\r\n padding: 0px 120px 0px 120px;\r\n}\r\n\r\n.siteMinWidth{\r\n min-width: 1200px;\r\n}\r\n\r\n.adminBar{\r\n width: 100%;\r\n position: fixed;\r\n bottom: 0px;\r\n background-color: #BBAA88;\r\n height: 20px;\r\n text-align: center;\r\n}', 3, 'l, F j Y \\a\\t g:i a');

-- --------------------------------------------------------

--
-- Table structure for table `file`
--
-- Creation: Aug 08, 2010 at 08:44 PM
-- Last update: Aug 09, 2010 at 05:19 AM
--

DROP TABLE IF EXISTS `file`;
CREATE TABLE IF NOT EXISTS `file` (
  `fileId` int(16) NOT NULL auto_increment,
  `filePath` varchar(256) NOT NULL,
  `fileSize` float NOT NULL,
  `fileType` varchar(4) NOT NULL,
  `objectId` int(16) NOT NULL,
  PRIMARY KEY  (`fileId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

-- --------------------------------------------------------

--
-- Table structure for table `group`
--
-- Creation: Aug 08, 2010 at 08:44 PM
-- Last update: Aug 08, 2010 at 08:44 PM
--

DROP TABLE IF EXISTS `group`;
CREATE TABLE IF NOT EXISTS `group` (
  `groupDescription` text NOT NULL,
  `groupId` int(16) NOT NULL auto_increment,
  `groupName` varchar(64) NOT NULL,
  PRIMARY KEY  (`groupId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `group`
--

INSERT DELAYED IGNORE INTO `group` (`groupDescription`, `groupId`, `groupName`) VALUES
('This group has unlimited access to the site. They can edit and change the site as they see fit. Only very important people should be in this group.', 1, 'Administrators');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--
-- Creation: Aug 08, 2010 at 08:44 PM
-- Last update: Aug 09, 2010 at 05:58 PM
--

DROP TABLE IF EXISTS `message`;
CREATE TABLE IF NOT EXISTS `message` (
  `messageId` int(16) NOT NULL auto_increment,
  `objectId` int(16) NOT NULL,
  `privateOwner` int(16) NOT NULL,
  PRIMARY KEY  (`messageId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

-- --------------------------------------------------------

--
-- Table structure for table `object`
--
-- Creation: Aug 08, 2010 at 08:44 PM
-- Last update: Aug 09, 2010 at 05:58 PM
--

DROP TABLE IF EXISTS `object`;
CREATE TABLE IF NOT EXISTS `object` (
  `createdId` int(16) NOT NULL,
  `createdOn` datetime NOT NULL,
  `objectId` int(16) NOT NULL auto_increment,
  `objectText` longtext NOT NULL,
  `parentId` int(16) NOT NULL,
  `objectTitle` varchar(64) NOT NULL,
  PRIMARY KEY  (`objectId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=73 ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--
-- Creation: Aug 08, 2010 at 08:44 PM
-- Last update: Aug 09, 2010 at 07:22 PM
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `icon` varchar(128) NOT NULL,
  `deleted` tinyint(1) NOT NULL,
  `userEmail` varchar(64) NOT NULL,
  `userId` int(16) NOT NULL auto_increment,
  `userName` varchar(64) NOT NULL,
  `userPassword` varchar(64) NOT NULL,
  PRIMARY KEY  (`userId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `user`
--

INSERT DELAYED IGNORE INTO `user` (`icon`, `deleted`, `userEmail`, `userId`, `userName`, `userPassword`) VALUES
('', 0, 'admin@admin.com', 2, 'Admin', '5f4dcc3b5aa765d61d8327deb882cf99');

-- --------------------------------------------------------

--
-- Table structure for table `userData`
--
-- Creation: Aug 08, 2010 at 08:44 PM
-- Last update: Aug 09, 2010 at 07:22 PM
--

DROP TABLE IF EXISTS `userData`;
CREATE TABLE IF NOT EXISTS `userData` (
  `data` varchar(128) NOT NULL,
  `dataId` int(16) NOT NULL,
  `userId` int(16) NOT NULL,
  `userDataId` int(16) NOT NULL auto_increment,
  PRIMARY KEY  (`userDataId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

-- --------------------------------------------------------

--
-- Table structure for table `userGroup`
--
-- Creation: Aug 08, 2010 at 08:44 PM
-- Last update: Aug 08, 2010 at 08:44 PM
--

DROP TABLE IF EXISTS `userGroup`;
CREATE TABLE IF NOT EXISTS `userGroup` (
  `groupId` int(16) NOT NULL,
  `leader` tinyint(1) NOT NULL,
  `userId` int(16) NOT NULL,
  `userGroupId` int(16) NOT NULL auto_increment,
  PRIMARY KEY  (`userGroupId`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `userGroup`
--

INSERT DELAYED IGNORE INTO `userGroup` (`groupId`, `leader`, `userId`, `userGroupId`) VALUES
(1, 1, 1, 2);
