WELCOME FOR OFOROS!

INSTALL INSTRUCTIONS===========================
1.	Copy the files to the directory you wish to install oforos
2.	Run the SQL file in this install folder
3.	Admin Login
	Email:		admin@admin.admin
	Password:	password
4.	Set the "tmp" and "uploads" folders to the permissions '777' (or non UNIX equivalent)
5.	Login via the admin and make your account
6.	Login to your database and move your account to the "Admin" group
7.	Delete the admin@admin.admin user
8.	Enjoy Oforos!

READ ME========================================
This site designed around simplicity. Everything you need should be all set after the initial set up instructions.
Please note the time of posting and adjust the timeOffset Environment Variable to compensate for any differences.
Remember the CSS Environment will over ride any values that are default. You can delete these at any time and restore
the site to the original design.

Any other questions should be directed to mdemaso@gmail.com or masserym@wit.edu.

Thank you for choosing Oforos and please respond to those emails with any feedback.

Enjoy!